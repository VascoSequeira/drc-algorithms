% Aplica��o do algoritmo DRC RapidM Algorithm 1 para um canal awgn com uma
% varia��o abrupta do SNR
clear all
close all
% Declara��o de constantes com vectores e vari�veis
snr_awgn = [-6.75; -4; -1.5; 2.02; 5.25; 7.6; 12.29; 14.69; 15.44; 20.48];
snr_good = [1.75; 2; 5.5; 12.18; 14.95; 21.4; 25.21; 30.71; 35.56; 42.02];
snr_poor = [-2.5; -1; 1; 7.1; 10.1; 15; 19.75; 22.2; 25.5; 29.75];
data_rate = [75; 150; 300; 600; 1200; 3200; 4800; 6400; 8000; 9600];
oscilacao=0;
robustez=0;
count=0;
delta_snr=0;
intervalo_snr=0;

% variaveis da recta y=mx+b para um canal good
m=244.52;
b=-1345.8;

%variaveis de apoio
soma_ber=0;
soma_fer=0;
soma_througput=0;

%produ��o dos valores de snr a variar ao longo dos 100 intervalos
for i=1:8
    snr(i)=0;
end
for l=9:18
    snr(l)=20;
end
for r=19:24
    snr(r)=0;
end
for a=25:31
    snr(a)=10;
end
for n=32:40
    snr(n)=15;
end
for c=41:47
    snr(c)=25;
end
for d=48:51
    snr(d)=20;
end
for e=52:61
    snr(e)=15;
end
for f=62:66
    snr(f)=12.5;
end
snr(67)=7.5;
snr(68)=7.5;
for g=69:77
    snr(g)=0;
end
for h=78:85
    snr(h)=10;
end
for k=86:100
    snr(k)=0;
end

%Inicializa��o
for i=1:10
    if(snr(1)<=snr_good(i))
        N=i;
        break;
    elseif(snr(1)>snr_good(10))
        N=10;
        break;
    end
end
datarate(1)=data_rate(N);

if(snr(1)<=0.5)
        ber(1)=1;
        datarate(1)=data_rate(1);
        fer(1)=0;
        througput(1)=0;
        count=count+1;
else   
%primeiro calculo
delta_snr=snr(1)-snr_good(N);
ber(1)=(10^(-5))*(10^(-delta_snr));
fer(1)=1-(1-ber(1))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
    if (fer(1)>=0.8)
        robustez=robustez+1;
    end
througput(1)=(1-fer(1))*datarate(1); 
end

%2� etapa assume-se canal awgn

if(ber(1)<10^(-11)&&N~=9&&N~=10)
    N=N+2;
    datarate(2)=data_rate(N);
    oscilacao=oscilacao+1;
elseif(ber(1)>10^(-11) && ber(1)<10^(-6)&&N~=10)
    N=N+1;
    datarate(2)=data_rate(N);
    oscilacao=oscilacao+1;
elseif(ber(1)>10^(-4)&&N~=1)
    N=N-1;
    datarate(2)=data_rate(N);
    oscilacao=oscilacao+1;
else
    datarate(2)=data_rate(N);
end

if(snr(2)<=0.5)
        ber(2)=1;
        datarate(2)=data_rate(1);
        fer(2)=0;
        througput(2)=0;
        count=count+1;
else   
delta_snr=snr(2)-snr_good(N);
ber(2)=(10^(-5))*(10^(-delta_snr));
 %valor limitador
    if(ber(1)>(10^(-3)))
        ber(1)=1;
    elseif(ber(1)<0)
        ber(1)=0;
    end
fer(2)=1-(1-ber(2))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
if (fer(2)>=0.8)
    robustez=robustez+1;
end
througput(2)=(1-fer(2))*datarate(2);
end

%Assume-se regra 3 porque delta_snr n�o varia mais de 9dB nem decai 12dB 
for j=3:100
   if(snr(j)<=0.5)
        N=1;
        ber(j)=1;
        datarate(j)=data_rate(1);
        fer(j)=0;
        througput(j)=0;
        count=count+1;
    else
    %Condi��es para aplicar as regras
    if(intervalo_snr<=-12)
        %Regra 1
        variacao_snr=snr(j-1)-((10*log10(data_rate(N))-b)/m);
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for x=1:10
            if(DRO<=data_rate(N))
                M=x;
                break
            elseif(DRO>data_rate(10) && x==10)
                M=10;
                break
            end
        end
        %verficar se deu mais de dois saltos para cima ou mais de 3 para
        %baixo
        if((M-N)>2)
            N=N+2;
        elseif((M-N)<-3)
            N=N-3;
        else
            N=M;
        end 
        
        datarate(j)=data_rate(N);
       
    elseif(snr(j)>=20 && data_rate(N)<=300)
        %Regra 1
        variacao_snr=snr(j-1)-((10*log10(data_rate(N))-b)/m);
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for y=1:10
            if(DRO<=data_rate(N))
                M=y;
                break
            elseif(DRO>data_rate(10) && y==10)
                M=10;
                break
            end
        end
        %verficar se deu mais de dois saltos para cima ou mais de 3 para
        %baixo
        if((M-N)>2)
            N=N+2;
        elseif((M-N)<-3)
            N=N-3;
        else
            N=M;
        end 
        
        datarate(j)=data_rate(N);
        
    elseif(intervalo_snr<=-9 || intervalo_snr>9)
        %Regra 2
        variacao_snr=(-10*log10(ber(j-1)))-4;
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for z=1:10
            if(DRO<=data_rate(N))
                M=z;
                break
            elseif(DRO>data_rate(10) && z==10)
                M=10;
                break
            end
        end
        %verficar se deu mais de dois saltos para cima ou mais de 3 para
        %baixo
        if((M-N)>2)
            N=N+2;
        elseif((M-N)<-3)
            N=N-3;
        else
            N=M;
        end 
        
        datarate(j)=data_rate(N);
       
    else
        %Regra3
        if(ber(j-1)<10^(-6)&&N~=10)
            N=N+1;
            datarate(j)=data_rate(N);
            oscilacao=oscilacao+1;
        elseif (ber(j-1)>10^(-4)&&N~=1)
            N=N-1;
            datarate(j)=data_rate(N);
            oscilacao=oscilacao+1;
        else
            datarate(j)=data_rate(N);
        end
    end
    
    intervalo_snr=snr(j)-snr(j-1);
    delta_snr=snr(j)-snr_good(N);
    ber(j)=(10^(-5))*(10^(-delta_snr));
     %valor limitador
    if(ber(j)>(10^(-3)))
        ber(j)=1;
    elseif(ber(j)<0)
        ber(j)=0;
    end
    
    %Realizar a previs�o se ultrapassa um BER 10E-3
    if(ber(j)==1 &&N~=1)
        count=count-1;
        N=N-1;
        datarate(j)=data_rate(N);
        delta_snr=snr(j)-snr_good(N);
        ber(j)=(10^(-5))*(10^(-delta_snr));
        %valor limitador
        if(ber(j)>10^(-3))
            ber(j)=1;
            count=count+1;
        elseif(ber(j)<0)
            ber(j)=0;
        end
    end
    
    fer(j)=1-(1-ber(j))^(250*8);
    %testar a robutez uma vez que corresponde a um FER maior ou igual que
    %80%
    if (fer(j)>=0.8)
        robustez=robustez+1;
    end
    
    througput(j)=(1-fer(j))*datarate(j);
   end
end

%oscila��es
osc=0;
for w=2:100
    if(datarate(w-1)~=datarate(w))
        osc=osc+1;
    end
end

%Configura��es no plot
figure
subplot(2,1,1);
plot(snr);
xlabel('Time(intervals)');
ylabel('SNR(dB)');
title('SNR em fun��o do tempo');

subplot(2,1,2);
plot(datarate);
xlabel('Time(intervals)');
ylabel('Data Rate(bit/s)');
title('Data Rate em fun��o o tempo');
hold on
