% Aplica��o do algoritmo DRC RapidM Algorithm 1 para um canal awgn com uma
% varia��o linear do SNR at� 20dB
clear all
close all
% Declara��o de constantes com vectores e vari�veis
snr_awgn = [-6.75; -4; -1.5; 2.02; 5.25; 10.75; 7.6; 12.29; 14.69; 15.44; 20.48];
snr_good = [1.75; 2; 5.5; 12.18; 14.95; 19.45; 21.4; 25.21; 30.71; 35.56; 42.02];
data_rate = [75; 150; 300; 600; 1200; 2400; 3200; 4800; 6400; 8000; 9600];
snr(1)=1;
snr(2)=2; %para este caso no inicio
oscilacao=0;
robustez=0;

% variaveis da recta y=mx+b para um canal good
m=244.52;
b=-1345.8;

%variaveis de apoio
soma_ber=0;
soma_fer=0;
soma_througput=0;

%Inicializa��o
for i=1:11
    if(snr(2)<=snr_good(i))
        N=i;
        break;
    end
end
datarate(snr(2))=data_rate(N);

%primeiro calculo
delta_snr=snr(2)-snr_awgn(N);
ber(2)=(10^(-5))*(10^(-delta_snr));
fer(2)=1-(1-ber(2))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
    if (fer(2)>=0.8)
        robustez=robustez+1;
    end
througput(2)=(1-fer(2))*datarate(2); 

%2� etapa assume-se canal awgn
snr(3)=snr(2)+1; %neste caso

if(ber(2)<10^(-11)&&N~=11&&N~=10)
    N=N+2;
    datarate(3)=data_rate(N);
    oscilacao=oscilacao+1;
elseif(ber(2)>10^(-11) && ber(2)<10^(-6)&&N~=11)
    N=N+1;
    datarate(3)=data_rate(N);
    oscilacao=oscilacao+1;
elseif(ber(2)>10^(-4)&&N~=1)
    N=N-1;
    datarate(3)=data_rate(N);
    oscilacao=oscilacao+1;
else
    datarate(3)=data_rate(N);
end

delta_snr=snr(3)-snr_awgn(N);
ber(snr(3))=(10^(-5))*(10^(-delta_snr));
fer(snr(3))=1-(1-ber(snr(3)))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
if (fer(snr(3))>=0.8)
    robustez=robustez+1;
end

througput(snr(3))=(1-fer(snr(3)))*datarate(snr(3));

%Assume-se regra 3 porque delta_snr n�o varia mais de 9dB nem decai 12dB 
for j=4:20
    snr(j)=j;
    
    %Condi��es para aplicar as regras
    if(delta_snr<=-12)
        %Regra 1
        variacao_snr=snr(j-1)-((10*log10(data_rate(N))-b)/m);
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for x=1:11
            if(DRO<=data_rate(N))
                N=x;
                break
            elseif(DRO>data_rate(11) && x==11)
                N=11;
                break
            end
        end
        datarate(j)=data_rate(N);
    elseif(snr(j-1)==20 && data_rate(N)<=300)
        %Regra 1
        variacao_snr=snr(j-1)-((10*log10(data_rate(N))-b)/m);
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for y=1:11
            if(DRO<=data_rate(N))
                N=x;
                break
            elseif(DRO>data_rate(11) && x==11)
                N=11;
                break
            end
        end
        datarate(j)=data_rate(N);
    elseif(delta_snr<=-9 || delta_snr>9)
        %Regra 2
        variacao_snr=(-10*log10(ber(j-1)))-4;
        delta_dr=m*variacao_snr;
        FDRL=(10*log10(data_rate(N))+delta_dr);
        DRO=10^(FDRL/10);
        for x=1:11
            if(DRO<=data_rate(N))
                N=x;
                break
            elseif(DRO>data_rate(11) && x==11)
                N=11;
                break
            end
        end
        datarate(j)=data_rate(N);
    else
        %Regra3
        if(ber(j-1)<10^(-6))
            N=N+1;
            datarate(j)=data_rate(N);
            oscilacao=oscilacao+1;
        elseif (ber(j-1)>10^(-4))
            N=N-1;
            datarate(j)=data_rate(N);
            oscilacao=oscilacao+1;
        else
            datarate(j)=data_rate(N);
        end
    end
    
    delta_snr=j-snr_awgn(N);
    ber(j)=(10^(-5))*(10^(-delta_snr));
    %valor limitador
    if(ber(j)>1)
        ber(j)=1;
    elseif(ber(j)<0)
        ber(j)=0;
    end
    
    fer(j)=1-(1-ber(j))^(250*8);
    %testar a robutez uma vez que corresponde a um FER maior ou igual que
    %80%
    if (fer(j)>=0.8)
        robustez=robustez+1;
    end
    througput(j)=(1-fer(j))*datarate(j);
end

%Calculo dos parametros de analise de performance

for t=2:20
    soma_ber=soma_ber+ber(t);
    soma_fer=soma_fer+fer(t);
    soma_througput=soma_througput+througput(t);
end

average_ber=soma_ber/19;
average_fer=soma_fer/19;
average_througput=soma_througput/19;

%Configura��es no plot
figure
subplot(2,1,1);
plot(snr);
xlabel('Time(intervals)');
ylabel('SNR(dB)');
title('SNR em fun��o do tempo');

subplot(2,1,2);
plot(datarate);
xlabel('Time(intervals)');
ylabel('Data Rate(bit/s)');
title('Data Rate em fun��o o tempo');
hold on

