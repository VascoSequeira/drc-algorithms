% Algoritmom Trinder para um canal GOOD iniciando aos 75bps e SNR inicial
% aos 2dB progredindo linearmente em +1 dB at� aos 20dB.
% Este algoritmo n�o utiliza o data rate de 2400bps, a transi��o � feita
% entre os 1200bps e os 3200bps
%considera-se o numero de bytes na trama de 250bytes
clear all
close all
% Declara��o de constantes com vectores e vari�veis
snr_good = [1.75; 2; 5.5; 12.18; 14.95; 19.45; 21.4; 25.21; 30.71; 35.56; 42.02];
snr_awgn = [-6.75; -4; -1.5; 2.02; 5.25; 7.6; 12.29; 14.69; 15.44; 20.48];
data_rate = [75; 150; 300; 600; 1200; 3200; 4800; 6400; 8000; 9600];
N=1;
BER_reduzir=[1; 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 2.154*10^(-4); 8.126*10^(-5); 2.565*10^(-5)];
BER_aumentar=[1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 5.268*10^(-5); 2.568*10^(-5); 2.568*10^(-5); 1.01*10^(-5); 0];
dr(1)=data_rate(N);
oscilacao=0;
snr(1)=1;
robustez=0;

%variaveis de apoio
soma_ber=0;
soma_fer=0;
soma_througput=0;

%primeiro calculo
delta_snr=snr(1)-snr_good(N);
ber(1)=(10^(-5))*(10^(-delta_snr));
%valor limitador
    if(ber(1)>1)
        ber(1)=1;
    elseif(ber(1)<0)
        ber(1)=0;
    end
    
fer(1)=1-(1-ber(1))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
    if (fer(1)>=0.8)
        robustez=robustez+1;
    end
througput(1)=(1-fer(1))*dr(1); 


%Algoritmo
for i=2:20
    snr(i)=i;
    %Condi��o para verificar se � maior ou menor que os valores de
    %threshold
    if(ber(i-1)>BER_reduzir(N))
        N=N-1;
        dr(i)=data_rate(N);
        oscilacao=oscilacao+1;
    elseif(ber(i-1)<BER_aumentar(N))
        N=N+1;
        dr(i)=data_rate(N);
        oscilacao=oscilacao+1;
    else
        dr(i)=data_rate(N);
    end
    
    delta_snr=i-snr_good(N);
   
    ber(i)=(10^(-5))*(10^(-delta_snr));
    %valor limitador
    if(ber(i)>1)
        ber(i)=1;
    elseif(ber(i)<0)
        ber(i)=0;
    end
    
    fer(i)=1-(1-ber(i))^(250*8);
    
    %testar a robutez uma vez que corresponde a um FER maior ou igual que
    %80%
    if (fer(i)>=0.8)
        robustez=robustez+1;
    end
    
    througput(i)=(1-fer(i))*dr(i);    
end

for t=1:20
    soma_ber=soma_ber+ber(t);
    soma_fer=soma_fer+fer(t);
    soma_througput=soma_througput+througput(t);
end

average_ber=soma_ber/20;
average_fer=soma_fer/20;
average_througput=soma_througput/20;

%Configura��es no plot
figure
subplot(2,1,1);
plot(snr);
xlabel('Time(intervals)');
ylabel('SNR(dB)');
title('SNR em fun��o do tempo');

subplot(2,1,2);
plot(dr);
xlabel('Time(intervals)');
ylabel('Data Rate(bit/s)');
title('Data Rate em fun��o o tempo');
hold on