% Algoritmom Trinder para um canal GOOD iniciando aos 75bps e SNR
% com varia��es abruptas num intervalo de 100 unidades 
% Este algoritmo n�o utiliza o data rate de 2400bps, a transi��o � feita
% entre os 1200bps e os 3200bps
%considera-se o numero de bytes na trama de 250bytes
clear all
close all
% Declara��o de constantes com vectores e vari�veis
snr_good = [1.75; 2; 5.5; 12.18; 14.95; 21.4; 25.21; 30.71; 35.56; 42.02];
snr_poor = [-2.5; -1; 1; 7.1; 10.1; 15; 19.75; 22.2; 25.5; 29.75];
data_rate = [75; 150; 300; 600; 1200; 3200; 4800; 6400; 8000; 9600];
BER_reduzir=[1; 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 3.465*10^(-4); 2.154*10^(-4); 8.126*10^(-5); 2.565*10^(-5)];
BER_aumentar=[1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 1.116*10^(-4); 5.268*10^(-5); 2.568*10^(-5); 2.568*10^(-5); 1.01*10^(-5); 0];
oscilacao=0;
delta_snr=0;
robustez=0;
count=0;

%variaveis de apoio
soma_ber=0;
soma_fer=0;
soma_througput=0;

%produ��o dos valores de snr a variar ao longo dos 100 intervalos
for i=1:8
    snr(i)=0;
end
for l=9:18
    snr(l)=20;
end
for r=19:24
    snr(r)=0;
end
for a=25:31
    snr(a)=10;
end
for b=32:40
    snr(b)=15;
end
for c=41:47
    snr(c)=25;
end
for d=48:51
    snr(d)=20;
end
for e=52:61
    snr(e)=15;
end
for f=62:66
    snr(f)=12.5;
end
snr(67)=7.5;
snr(68)=7.5;
for g=69:77
    snr(g)=0;
end
for h=78:85
    snr(h)=10;
end
for k=86:100
    snr(k)=0;
end

%Inicializa��o
for i=1:10
    if(snr(1)<=snr_good(i))
        N=i;
        break;
    elseif(snr(1)>snr_good(10))
        N=10;
        break;
    end
end
dr(1)=data_rate(N);

if(snr(1)<=-4.04)
     ber(1)=0;
     dr(1)=data_rate(1);
     fer(1)=0;
     througput(1)=0;
     count=count+1;
else
%primeiro calculo
delta_snr=snr(1)-snr_poor(N);
ber(1)=(10^(-5))*(10^(-delta_snr));
%valor limitador
    if(ber(1)>10^(-3))
        ber(1)=1;
        count=count+1;
    elseif(ber(1)<0)
        ber(1)=0;
    end
fer(1)=1-(1-ber(1))^(250*8);
%testar a robutez uma vez que corresponde a um FER maior ou igual que
%80%
    if (fer(1)>=0.8)
        robustez=robustez+1;
    end
througput(1)=(1-fer(1))*dr(1); 
end


%Algoritmo
for j=2:100
    
    if(snr(j)<=-4.04)
         if(N==1)
            N=1;
        else
            N=N-1;
        end
        ber(j)=1;
        dr(j)=data_rate(N);
        fer(j)=0;
        througput(j)=0;
        count=count+1;
    else   
    %Condi��o para verificar se � maior ou menor que os valores de
    %threshold
    if(ber(j-1)>BER_reduzir(N))
        N=N-1;
        dr(j)=data_rate(N);
        oscilacao=oscilacao+1;
    elseif(ber(j-1)<BER_aumentar(N))
        N=N+1;
        dr(j)=data_rate(N);
        oscilacao=oscilacao+1;
    else
        dr(j)=data_rate(N);
    end
    
    delta_snr=snr(j)-snr_poor(N);
    ber(j)=(10^(-5))*(10^(-delta_snr));
    %valor limitador
    if(ber(j)>10^(-3)) %ao corte
        ber(j)=1;
        count=count+1;
    elseif(ber(j)<0)
        ber(j)=0;
    end
    
      %Realizar a previs�o se ultrapassa um BER do threshold para reduzir
    if(ber(j)>BER_reduzir(N) &&N~=1)
        count=count-1;
        N=N-1;
        dr(j)=data_rate(N);
        delta_snr=snr(j)-snr_poor(N);
        ber(j)=(10^(-5))*(10^(-delta_snr));
        %valor limitador
        if(ber(j)>10^(-3))
            ber(j)=1;
            count=count+1;
        elseif(ber(j)<0)
            ber(j)=0;
        end
    end
    
    fer(j)=1-(1-ber(j))^(250*8);
    %testar a robutez uma vez que corresponde a um FER maior ou igual que
    %80%
    if (fer(j)>=0.8)
        robustez=robustez+1;
    end
    
    througput(j)=(1-fer(j))*dr(j);   
    end
end

%oscila��es
osc=0;
for w=2:100
    if(dr(w-1)~=dr(w))
        osc=osc+1;
    end
end

for t=1:100
    soma_ber=soma_ber+ber(t);
    soma_fer=soma_fer+fer(t);
    soma_througput=soma_througput+througput(t);
end

average_ber=soma_ber/100;
average_fer=soma_fer/100;
average_througput=soma_througput/100;

%Configura��es no plot
figure
subplot(2,1,1);
plot(snr);
xlabel('Time(intervals)');
ylabel('SNR(dB)');
title('SNR em fun��o do tempo');

subplot(2,1,2);
plot(dr);
xlabel('Time(intervals)');
ylabel('Data Rate(bit/s)');
title('Data Rate em fun��o o tempo');
hold on